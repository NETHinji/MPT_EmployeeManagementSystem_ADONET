﻿using System;
using System.Runtime.Serialization;

namespace Employee.Exception
{
    [Serializable]
    public class EmployeeException : System.Exception
    {
        public EmployeeException()
        {
        }

        public EmployeeException(string message) : base(message)
        {
        }

        public EmployeeException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected EmployeeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}