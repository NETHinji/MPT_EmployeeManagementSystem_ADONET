﻿using Employee.Entities;
using Employee.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Employee.Entities;
using Employee.DL;

using Emplyee.BL;
using System.Data;

namespace Employee.PresentationLayer
{
        public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //cmbx.DataSource = Enum.GetValues(typeof(City));

            foreach (var items in Enum.GetValues(typeof(EmployeeM.City)))
            { cmbx.Items.Add(items); }
        }
     
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                EmployeeM e1 = new EmployeeM
                {

                    EmployeeName = txtNm.Text,
                    EmpEmailid = txtEmail.Text,
                    ContactNo = Convert.ToDouble(txtMob.Text),
                    city = cmbx.SelectedValue.ToString(),
                    date = Convert.ToDateTime(txtdate.Text)

                };

                EmployeeBLL eb = new EmployeeBLL();
                 bool added=eb.AddEmpl(e1);

                if (added)
                {
                    MessageBox.Show(string.Format("New Employee Added"));
                }
                else
                {
                    MessageBox.Show("Not added");
                }
            }
            catch (System.Exception)
            {

                throw;
            }
        }

       
        private void txtMob_Copy_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               // EmployeeM e1 = new EmployeeM();
                int delId = Convert.ToInt32(txtsearch.Text);
                EmployeeBLL ebl = new EmployeeBLL();
                bool delEmp=ebl.DeleteEmp(delId);
                if (delEmp)
                {
                    MessageBox.Show("Employee deleted ");
                }
                else
                {
                    MessageBox.Show("Employee not deleted ");
                }
                txtNm.Clear();
                txtEmail.Clear();
                txtMob.Clear();
            }
            catch (System.Exception)
            {

                throw;
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeBLL ebl = new EmployeeBLL();
                DataTable dt=ebl.ListEmp();
                if (dt != null)
                {
                    dgEmployee.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Table is empty", "Product Management System");
                }
            }
            catch (System.Exception)
            {

                throw;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            bool isUp=false;
            EmployeeM e1 = new EmployeeM
            {
                EmployeeName = txtNm.Text,
                EmpEmailid = txtEmail.Text,
                ContactNo = Convert.ToDouble(txtMob.Text)
            };
            int EmpId = Convert.ToInt32(txtsearch.Text);
            EmployeeBLL ebl = new EmployeeBLL();
            isUp=ebl.UpdateEmp(e1,EmpId);
            if(isUp)
            {
                MessageBox.Show("Updated");
              }
            else
            {
                MessageBox.Show(" Not Updated");
            }
            
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            EmployeeM emp = null;
            try
            {

                EmployeeBLL ebl = new EmployeeBLL();
                emp = ebl.searchEmp(Convert.ToInt32(txtsearch.Text));
                MessageBox.Show(emp.EmployeeName + " " + emp.EmpEmailid + " " + emp.ContactNo);

                
            }
            catch (System.Exception)
            {

                throw;
            }
           
        }

        
    }
}
