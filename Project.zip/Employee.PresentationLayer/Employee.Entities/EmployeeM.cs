﻿using System;

namespace Employee.Entities
{
    public class EmployeeM
    {
        
        
        public string EmployeeName { get; set; }
        public string EmpEmailid { get; set; }
        public double ContactNo { get; set; }
        public string city { get; set; }
        public DateTime date { get; set; }
          
      

    public enum City
    {
        Pune=1,
        Mumbai=2,
        Benglore=3
    }
}
        
    }
