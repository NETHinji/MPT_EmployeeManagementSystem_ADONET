﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.Entities;
using System.Configuration;



namespace Employee.DL
{
    public class EmployeeDl
    {
        //string _myConnectionString = @"data source=ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog=training_19sep18_pune;";
        SqlCommand cmd = new SqlCommand();
        static string Con = string.Empty;
        SqlConnection con1;

        static EmployeeDl()
        {
            Con= ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
        }

        public EmployeeDl()
        {
          con1 = new SqlConnection(Con);
        }

        public int AddEmpl(EmployeeM e1)
        {
            int eid;
            try
            {             
                    cmd.CommandText = "CapG.AddEmp1";
                    cmd.Connection = con1;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@eId", SqlDbType.Int);
                    cmd.Parameters["@eId"].Direction = ParameterDirection.Output;

                    cmd.Parameters.AddWithValue("@eName", e1.EmployeeName);
                    cmd.Parameters.AddWithValue("@eEmail", e1.EmpEmailid);
                    cmd.Parameters.AddWithValue("@eContact", e1.ContactNo);
                    cmd.Parameters.AddWithValue("@city", e1.city);
                    cmd.Parameters.AddWithValue("@dttm", e1.date);

                    con1.Open();
                    cmd.ExecuteNonQuery();
                    eid = int.Parse(cmd.Parameters["@eId"].Value.ToString());
   
            }
            catch (Exception)
            {

                throw;
            }
            return eid;
           
            }

        public EmployeeM searchEmp(int v)
        {
            EmployeeM em = null;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "CapG.SelectChoice";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@eId", v);

                con1.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    em = new EmployeeM
                    {
                        EmployeeName = dr["Employee_Nmae"].ToString(),
                        EmpEmailid = dr["Employee_Emailid"].ToString(),
                        ContactNo = int.Parse(dr["Employee_contact"].ToString())

                    };


                }
            }
            catch (Exception)
            {

                throw;
            }
            return em;
        }

        public bool UpdateEmp(EmployeeM e1,int EmpId)
        {
            bool result = false;
            try
            {
                cmd.CommandText = "CapG.UpdateEmp";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@eid", EmpId);
                cmd.Parameters.AddWithValue("@eName", e1.EmployeeName);
                cmd.Parameters.AddWithValue("@eEmail", e1.EmpEmailid);
                cmd.Parameters.AddWithValue("@eContact", e1.ContactNo);
                con1.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }


            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }

        public DataTable ListEmp()
        {
            DataTable dt = null;
            try
            {
                
                    cmd.CommandText = "CapG.SelectAll";
                    cmd.Connection = con1;
                    cmd.CommandType = CommandType.StoredProcedure;

                    con1.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return dt;
        }

        public bool DeleteEmp(int delId)
        {
            bool result = false;
            try
            {
                
                    con1.Open();
                    cmd.CommandText = "CapG.DeleteEMp";
                    cmd.Connection = con1;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@eid", delId);
                    
                    int noOfRowsAffected = cmd.ExecuteNonQuery();
                    if (noOfRowsAffected == 1)
                    {   result = true;    }

                
            }
            catch (Exception)
            {

                throw;
            }
            return result;
        }






    }
    }

