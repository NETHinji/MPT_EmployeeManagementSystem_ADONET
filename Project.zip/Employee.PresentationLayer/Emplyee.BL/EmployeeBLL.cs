﻿using System;
using Employee.Entities;
using Employee.DL;
using System.Data;
using System.Text.RegularExpressions;

namespace Emplyee.BL
{
    public class EmployeeBLL
    {
        public EmployeeBLL()
        {
        }

        public bool AddEmpl(EmployeeM e1)
        {
            bool validateEmp = false;
            try
            {
               
                if (ValidateEmp(e1))
                {
                    EmployeeDl edl = new EmployeeDl();
                    edl.AddEmpl(e1);
                    validateEmp = true;
                    
                }
                

            }
            catch (Exception)
            {

                throw;
            }
            return validateEmp;
        }

        private bool ValidateEmp(EmployeeM e1)
        {
            bool validateEmp = true;
            Regex contact = new Regex("([8-9]{1})([0-9]{9})");
            Regex mail = new Regex(@"([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)");
            
            try
            {
                if (!contact.Match(Convert.ToString(e1.ContactNo)).Success)
                    { validateEmp = false; }
                if(!mail.Match(e1.EmpEmailid).Success)
                    { validateEmp = false; }

               
            }
            catch (Exception)
            {

                throw;
            }
            return validateEmp;
        }

        public bool DeleteEmp(int delId)
        {
            EmployeeDl edl = new EmployeeDl();
            return edl.DeleteEmp(delId);
        }

        public DataTable ListEmp()
        {
            EmployeeDl edl = new EmployeeDl();
            return edl.ListEmp();
        }

        public bool UpdateEmp(EmployeeM e1, int empId)
        {
            EmployeeDl edl = new EmployeeDl();
            return edl.UpdateEmp(e1, empId);

        }

        public EmployeeM searchEmp(int v)
        {
            EmployeeDl edl = new EmployeeDl();
            return edl.searchEmp(v);
        }
    }
}