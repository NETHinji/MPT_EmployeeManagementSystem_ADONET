﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.Entities;
using Employee.DL;
using System.Data;

namespace Employee.BL
{
    public class EmployeeBl
    {
        public int AddEmpl(EmployeeM e1)
        {

            try
            {
                EmployeeDl edl = new EmployeeDl();
                return edl.AddEmpl(e1);

            }
            catch (Exception)
            {

                throw;
            }


        
        }

        public bool DeleteEmp(int delId)
        {
            try
            {
                EmployeeDl edl = new EmployeeDl();
                return edl.DeleteEmp(delId);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void ListEmp()
        {
            try
            {
                EmployeeDl edl = new EmployeeDl();
                edl.ListEmp();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool UpdateEmp(EmployeeM e1,int EmpId)
        {

            EmployeeDl edl = new EmployeeDl();
             return edl.UpdateEmp(e1,EmpId);
        }
    }
}
