﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Employee
    {
        public int EmpId { get; set; }
        public int Salary { get; set; }
        public string EmpName { get; set; }
        public string Address { get; set; }
        public int NoOfProjects { get; set; }
        public EPositions EmpPosition { get; set; }
        public long ContactNo { get; set; }
        public enum EPositions
        {
            Analyst,
            Consultant,
            SeniorConsultant,
            Manager
        };
    }
    
}
