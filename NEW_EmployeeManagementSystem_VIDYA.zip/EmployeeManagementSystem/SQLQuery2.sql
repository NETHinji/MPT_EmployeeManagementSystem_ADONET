use Training_19Sep18_Pune
go

create schema Vidya_Employee
go


create table Vidya_Employee.Employee1
(
EmployeeId int identity(1,1) primary key,
EmployeeName varchar(25) unique not null,
[Address] varchar(250) null,
Salary money not null,
NoOfProjects int not null,
Position varchar(20) not null
)


alter proc Vidya_Employee.uspAddEmployee1
(
@eName varchar(25),
@addr varchar(250),
@sal money,
@nop int,
@pos varchar(20),
@eId int output
)
as
begin
	insert into Vidya_Employee.Employee1
	values(@eName,@addr,@sal,@nop,@pos)

	set @eId = Scope_Identity()
end

alter proc Vidya_Employee.uspEditEmployee1
(
@eId int,
@eName varchar(25),
@addr varchar(250),
@sal money,
@nop int,
@pos int
)
as
begin
	update Vidya_Employee.Employee1
	set EmployeeName = @eName,[Address]=@addr,
	Salary=@sal,NoOfProjects=@nop,Position=@pos
	where EmployeeId = @eId
end

create proc Vidya_Employee.uspDeleteEmployee1
(
@eId int
)
as
begin
	delete from Vidya_Employee.Employee1
	where EmployeeId = @eId
end

create proc Vidya_Employee.uspSearchEmployee1
(
@eId int
)
as
begin
	select * from Vidya_Employee.Employee1
	where EmployeeId = @eId
end

create proc Vidya_Employee.uspGetEmployees1
as
begin
	select * from Vidya_Employee.Employee1
end

create proc Vidya_Employee.uspGetPositions
as
begin
	select PositionId,PositionName 
	from Vidya_Employee.Position
	order by PositionId
end

alter proc Vidya_Employee.uspNextEmployeeId1
as
begin
select IDENT_CURRENT('Vidya_Employee.Employee1') +IDENT_Incr('Vidya_Employee.Employee1') 
end


select * from Vidya_Employee.Employee1