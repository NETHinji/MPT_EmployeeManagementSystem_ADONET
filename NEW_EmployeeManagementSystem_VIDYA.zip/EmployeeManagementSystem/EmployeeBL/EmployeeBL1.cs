﻿using DataAccessLayer;
using Entities;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeBL
{
    public class EmployeeBL1
    {

        public int AddEmployee(Employee pobj)
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.AddEmployee(pobj);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public bool EditEmployee(Employee pobj)
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.EditEmployee(pobj);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public bool DeleteEmployee(int EmployeeId)
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.DeleteEmployee(EmployeeId);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public Employee Search(int EmployeeId)
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.Search(EmployeeId);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public DataTable Display()
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.Display();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public DataTable GetPosition()
        {
            try
            {
                EmployeeDal pd = new EmployeeDal();
                return pd.GetPositions();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
    }
}
