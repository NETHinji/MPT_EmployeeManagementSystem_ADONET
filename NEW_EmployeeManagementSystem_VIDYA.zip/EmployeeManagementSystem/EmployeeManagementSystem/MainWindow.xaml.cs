﻿using Entities;
using Exceptions;
using System;
using EmployeeBL;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace EmployeeManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddCategory_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee emp = new Employee
                {
                    EmpName = txtEName.Text,
                    Address = txtAddr.Text,
                    Salary = int.Parse(txtEID.Text),
                    NoOfProjects = int.Parse(txtNoOfProjects.Text),

                    //changes

                    EmpPosition = (Employee.EPositions) Enum.Parse(typeof(Employee.EPositions),cmbPosition.SelectedValue.ToString())
                   
               
                };
                EmployeeBL1 eb = new EmployeeBL1();
                int eid = eb.AddEmployee(emp);
                MessageBox.Show(string.Format("New Employee Added.\nEmployee Id: {0}", eid),
                    "Employee Management System");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                /*EmployeeBL1 pb = new EmployeeBL1();
                DataTable dt = pb.GetPosition();
                if (dt != null)
                {
                    cmbPosition.ItemsSource = dt.DefaultView;
                    cmbPosition.DisplayMemberPath = ;
                    cmbPosition.SelectedValuePath = "PositionId";
                }
                else
                {
                    MessageBox.Show("Table is empty", "Employee Management System");
                }*/
                foreach (var item in Enum.GetValues(typeof(Employee.EPositions)))
                {
                    cmbPosition.Items.Add(item);
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void txtEName_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void txtEName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void txtNoOfProjects_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtNoOfProjects.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                txtNoOfProjects.Text = txtNoOfProjects.Text.Remove(txtNoOfProjects.Text.Length - 1);
            }
        }

        private void txtContact_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtContact.Text, @"[^0-9]$"))
            {
                MessageBox.Show("This accepts only numeric characters");
                txtContact.Text.Remove(txtContact.Text.Length - 1);
            }

            if (System.Text.RegularExpressions.Regex.IsMatch(txtContact.Text, @"^([89]\d{10}|[0-7]\d*)$"))
            {
                MessageBox.Show("Please enter a valid number...");
                txtContact.Text = txtContact.Text.Remove(txtContact.Text.Length - 1);
            }

        }
    }
}
