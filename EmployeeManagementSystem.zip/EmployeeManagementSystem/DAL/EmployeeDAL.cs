﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer
{
    public class EmployeeDal
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="eobj"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static EmployeeDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public EmployeeDal()
        {
            con = new SqlConnection(conStr);

        }

        public int AddEmployee(Employee eobj)
        {
            int eid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Employee.uspAddEmployee1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@eId", SqlDbType.Int);
                cmd.Parameters["@eId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@ename", eobj.EmpName);
                cmd.Parameters.AddWithValue("@addr", eobj.Address);
                cmd.Parameters.AddWithValue("@sal", eobj.Salary);
                cmd.Parameters.AddWithValue("@nop", eobj.NoOfProjects);

               
                cmd.Parameters.AddWithValue("@pos", eobj.EmpPosition);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                eid = int.Parse(cmd.Parameters["@eId"].Value.ToString());
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return eid;
        }

        public bool EditEmployee(Employee eobj)
        {
            bool result = false;
            try
            {
                // con = new SqlConnection();
                //   con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Employee.uspEditEmployee1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@eId", eobj.EmpId);
                cmd.Parameters.AddWithValue("@eName", eobj.EmpName);
                cmd.Parameters.AddWithValue("@addr", eobj.Address);
                cmd.Parameters.AddWithValue("@sal", eobj.Salary);
                cmd.Parameters.AddWithValue("@nop", eobj.NoOfProjects);
                cmd.Parameters.AddWithValue("@pos", eobj.EmpPosition);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public bool DeleteEmployee(int EmployeeId)
        {
            bool result = false;
            try
            {
                //  con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Employee.uspDeleteEmployee1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@eId", EmployeeId);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeException)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public Employee Search(int EmployeeId)
        {
            Employee p = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Employee.uspSearchEmployee1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@eId", EmployeeId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Employee
                    {
                        EmpId = int.Parse(dr["EmployeeId"].ToString()),
                        EmpName = dr["EmployeeName"].ToString(),
                        Address = dr["Address"].ToString(),
                        Salary = (int)decimal.Parse(dr["Salary"].ToString()),
                        NoOfProjects = int.Parse(dr["NoOfProjects"].ToString()),
                        //treat pending
                        EmpPosition = (Employee.EPositions)Enum.Parse(typeof(Employee.EPositions),dr["Position"].ToString())
                        
                    };
                    dr.Close();
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }

        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Employee.uspGetEmployees1";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

        public DataTable GetPositions()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Vidya_Employee.uspGetPositions";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
