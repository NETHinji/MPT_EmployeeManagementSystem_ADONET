use Training_19Sep18_Pune

create table Vidya_Customer_161363
(
CustID varchar(50) Primary Key, FirstName Varchar(50), LastName Varchar(50), OrderID varchar(50)
)



create table Vidya_Order_161363
(
OrderID varchar(50) Primary Key, CustID Varchar(50), OrderName Varchar(50)
)

